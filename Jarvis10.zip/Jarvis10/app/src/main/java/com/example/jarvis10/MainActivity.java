package com.example.jarvis10;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;
import java.net.URISyntaxException;

public class MainActivity extends AppCompatActivity {

    private WebSocketClient webSocketClient;
    private TextView connectionStatus;
    private ImageButton btnForward, btnBackward, btnLeft, btnRight, btnConnect;
    private ImageButton btnDriftLeft, btnDriftRight;
    private boolean isConnected = false;

    private final String CAR_IP = "192.168.4.1";
    private final int CAR_PORT = 81;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        setupEventListeners();
    }

    private void initializeViews() {
        connectionStatus = findViewById(R.id.connectionStatus);
        btnForward = findViewById(R.id.btnForward);
        btnBackward = findViewById(R.id.btnBackward);
        btnLeft = findViewById(R.id.btnLeft);
        btnRight = findViewById(R.id.btnRight);
        btnConnect = findViewById(R.id.btnConnect);
        btnDriftLeft = findViewById(R.id.btnDriftLeft);
        btnDriftRight = findViewById(R.id.btnDriftRight);

        updateConnectionStatus(false);
    }

    private void setupEventListeners() {
        // Forward button - Press=Forward, Release=Stop
        btnForward.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sendCommand("B");
                        btnForward.setAlpha(0.7f);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        sendCommand("STOP");
                        btnForward.setAlpha(1.0f);
                        return true;
                }
                return false;
            }
        });

        // Backward button - Press=Backward, Release=Stop
        btnBackward.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sendCommand("F");
                        btnBackward.setAlpha(0.7f);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        sendCommand("STOP");
                        btnBackward.setAlpha(1.0f);
                        return true;
                }
                return false;
            }
        });

        // Left Turn Button - Press=Left, Release=Stop Steering
        btnLeft.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sendCommand("L");
                        btnLeft.setAlpha(0.7f);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        sendCommand("STOP_STEER");
                        btnLeft.setAlpha(1.0f);
                        return true;
                }
                return false;
            }
        });

        // Right Turn Button - Press=Right, Release=Stop Steering
        btnRight.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sendCommand("R");
                        btnRight.setAlpha(0.7f);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        sendCommand("STOP_STEER");
                        btnRight.setAlpha(1.0f);
                        return true;
                }
                return false;
            }
        });

        // Drift Left button
        btnDriftLeft.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sendCommand("DRIFT_LEFT_START");
                        btnDriftLeft.setAlpha(0.7f);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        sendCommand("DRIFT_STOP");
                        btnDriftLeft.setAlpha(1.0f);
                        return true;
                }
                return false;
            }
        });

        // Drift Right button
        btnDriftRight.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sendCommand("DRIFT_RIGHT_START");
                        btnDriftRight.setAlpha(0.7f);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        sendCommand("DRIFT_STOP");
                        btnDriftRight.setAlpha(1.0f);
                        return true;
                }
                return false;
            }
        });

        // Connect button
        btnConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isConnected) {
                    disconnectFromCar();
                } else {
                    connectToCar();
                }
            }
        });
    }

    // KEEP ALL YOUR EXISTING WEBSOCKET METHODS EXACTLY THE SAME
    private void connectToCar() {
        try {
            URI serverUri = new URI("ws://" + CAR_IP + ":" + CAR_PORT);

            webSocketClient = new WebSocketClient(serverUri) {
                @Override
                public void onOpen(ServerHandshake handshakedata) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            isConnected = true;
                            updateConnectionStatus(true);
                            Toast.makeText(MainActivity.this, "Connected to car!", Toast.LENGTH_SHORT).show();
                        }
                    });
                }

                @Override
                public void onMessage(String message) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            System.out.println("Received: " + message);
                        }
                    });
                }

                @Override
                public void onClose(int code, String reason, boolean remote) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            isConnected = false;
                            updateConnectionStatus(false);
                            Toast.makeText(MainActivity.this, "Disconnected from car", Toast.LENGTH_SHORT).show();
                        }
                    });
                }

                @Override
                public void onError(Exception ex) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            isConnected = false;
                            updateConnectionStatus(false);
                            Toast.makeText(MainActivity.this, "Connection error: " + ex.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            };

            webSocketClient.connect();

        } catch (URISyntaxException e) {
            Toast.makeText(this, "Invalid server URI", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    private void disconnectFromCar() {
        if (webSocketClient != null) {
            webSocketClient.close();
            webSocketClient = null;
        }
        isConnected = false;
        updateConnectionStatus(false);
    }

    public void sendCommand(String command) {
        if (isConnected && webSocketClient != null) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        webSocketClient.send(command);
                        System.out.println("Sent: " + command);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        } else {
            System.out.println("Not connected - Command not sent: " + command);
        }
    }

    private void updateConnectionStatus(boolean connected) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                isConnected = connected;
                if (connected) {
                    connectionStatus.setText("CONNECTED");
                    connectionStatus.setBackgroundColor(ContextCompat.getColor(MainActivity.this, android.R.color.holo_green_dark));
                    btnConnect.setImageResource(R.drawable.ic_disconnect);
                } else {
                    connectionStatus.setText("DISCONNECTED");
                    connectionStatus.setBackgroundColor(ContextCompat.getColor(MainActivity.this, android.R.color.holo_red_dark));
                    btnConnect.setImageResource(R.drawable.ic_connect);
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        disconnectFromCar();
    }
}